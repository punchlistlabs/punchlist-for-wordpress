<div class="wrap">
    <?php wp_nonce_field('pl_check_integration', 'plnonce'); ?>
    <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
    <h3>To unlock the full functionality of this plugin you must get an API key from your <a href="https://app.usepunchlist.com/settings">Punchlist account.</a></h3>

    <form id="set-up-api">
        <!-- <label for="api-key">API Key</label> -->
        <div>
            <input type="password" name="api-key" value="<?php echo get_user_meta(get_current_user_id(), 'pl-api-key', true) ?>" placeholder="API Key" />
            <input type="submit" id="submit-api-key" class="button button-primary" alt="Integrate with Punchlist API" value="Verify API Integration" />
        </div>
        <!-- <div>
            <select name="set-default-project" id="set-default-project">
                <option value="">Set Default Project</option>
            </select>
        </div> -->
    </form>
</div><!-- .wrap -->